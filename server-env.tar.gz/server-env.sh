#!/usr/bin/env bash

# Install
sudo apt update
sudo apt install -y vim
sudo apt install -y neovim
sudo apt install -y zsh
sudo apt install -y mc
sudo apt install -y tree
sudo apt install -y htop
sudo apt install -y npm

# Install/npm
npm install jsonlint -g

# Zsh Setup
sh -c "$(curl -fsSL https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
chsh -s $(which zsh) $(whoami)
sed -i 's/ZSH_THEME="robbyrussell"/# ZSH_THEME="robbyrussell"\nZSH_THEME="lukerandall"/' $HOME/.zshrc
echo '. $HOME/.bash_aliases' >> $HOME/.zshrc

# Vim plug
curl -fLo ~/.vim/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim

# Nvim plug
curl -fLo ~/.local/share/nvim/site/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim

# Midnight Commander Skin
mkdir -p $HOME/.local/share/mc/skins/
cp darkcourses_green.ini $HOME/.local/share/mc/skins/
mc
sed -i 's/skin=default/skin=darkcourses_green/' $HOME/.config/mc/ini

# Vim Setup
CURRENT_USER=$USER
sudo -E bash -c 'echo "\" $CURRENT_USER" >> $HOME/.vimrc'
sudo bash -c 'echo >> $HOME/.vimrc'
sudo bash -c 'echo "\" set background=dark" >> $HOME/.vimrc'
sudo bash -c 'echo "set number" >> $HOME/.vimrc'
sudo bash -c 'echo "set is" >> $HOME/.vimrc'
sudo bash -c 'echo "set cindent" >> $HOME/.vimrc'
sudo bash -c 'echo "set expandtab" >> $HOME/.vimrc'
sudo bash -c 'echo "set tabstop=4" >> $HOME/.vimrc'
sudo bash -c 'echo "set shiftwidth=4" >> $HOME/.vimrc'
sudo bash -c 'echo "set mouse=a" >> $HOME/.vimrc'
sudo bash -c 'echo "set splitright" >> $HOME/.vimrc'
# Plug
sudo bash -c 'echo >> $HOME/.vimrc'
sudo bash -c 'echo "call plug#begin('\''~/.vim/plugged'\'')" >> $HOME/.vimrc'
sudo bash -c 'echo >> $HOME/.vimrc'
sudo bash -c 'echo "Plug '\''https://github.com/NLKNguyen/papercolor-theme'\''" >> $HOME/.vimrc'
sudo bash -c 'echo >> $HOME/.vimrc'
sudo bash -c 'echo "call plug#end()" >> $HOME/.vimrc'
sudo bash -c 'echo >> $HOME/.vimrc'
# Color Theme
sudo bash -c 'echo "set t_Co=256" >> $HOME/.vimrc'
sudo bash -c 'echo "set background=dark" >> $HOME/.vimrc'
sudo bash -c 'echo "colorscheme PaperColor" >> $HOME/.vimrc'
# Keyboard Shortcuts remap
sudo bash -c 'echo >> $HOME/.vimrc'
sudo bash -c 'echo "tnoremap <Esc><Esc> <C-\><C-n>" >> $HOME/.vimrc'
sudo bash -c 'echo "tnoremap <C-h> <C-\><C-n><C-w>h" >> $HOME/.vimrc'
sudo bash -c 'echo "tnoremap <C-j> <C-\><C-n><C-w>j" >> $HOME/.vimrc'
sudo bash -c 'echo "tnoremap <C-k> <C-\><C-n><C-w>k" >> $HOME/.vimrc'
sudo bash -c 'echo "tnoremap <C-l> <C-\><C-n><C-w>l" >> $HOME/.vimrc'
sudo bash -c 'echo "nnoremap <C-h> <C-w>h" >> $HOME/.vimrc'
sudo bash -c 'echo "nnoremap <C-j> <C-w>j" >> $HOME/.vimrc'
sudo bash -c 'echo "nnoremap <C-k> <C-w>k" >> $HOME/.vimrc'
sudo bash -c 'echo "nnoremap <C-l> <C-w>l" >> $HOME/.vimrc'

# Vim Pluginstall
vim -c PlugInstall -c qa

# Nvim Setup
mkdir -p $HOME/.config/nvim
cat $HOME/.vimrc > $HOME/.config/nvim/init.vim
sed -i 's/\~\/\.vim\/plugged/\~\/\.local\/share\/nvim\/plugged/' $HOME/.config/nvim/init.vim 
echo "vnoremap <C-c> \"+y" >> $HOME/.config/nvim/init.vim
echo "nnoremap <C-v> o<Esc>\"+p0" >> $HOME/.config/nvim/init.vim
sed -i '5 i set nohlsearch' $HOME/.config/nvim/init.vim
sed -i '13 i set nomodeline' $HOME/.config/nvim/init.vim

# Nvim Pluginstall
nvim -c PlugInstall -c qa

# Aliases
echo "alias wwwdo='sudo -u www-data'" >> $HOME/.bash_aliases

