#!/usr/bin/env bash

# VARIABLES
CURRENT_USER=$USER

# Install
sudo apt update
sudo apt install -y vim
sudo apt install -y neovim
sudo apt install -y zsh
sudo apt install -y mc
sudo apt install -y tree
sudo apt install -y htop

# Zsh Setup
sh -c "$(curl -fsSL https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
chsh -s $(which zsh) $(whoami)
sed -i 's/ZSH_THEME="robbyrussell"/# ZSH_THEME="robbyrussell"\nZSH_THEME="lukerandall"/' $HOME/.zshrc
echo '. $HOME/.bash_aliases' >> $HOME/.zshrc

# Vim plug
curl -fLo ~/.vim/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim

# Midnight Commander Skin
mkdir -p $HOME/.local/share/mc/skins/
cp darkcourses_green.ini $HOME/.local/share/mc/skins/
mc
sed -i 's/skin=default/skin=darkcourses_green/' $HOME/.config/mc/ini

# Vim Setup
echo "\" $CURRENT_USER" >> $HOME/.vimrc
echo >> $HOME/.vimrc
echo "\" set background=dark" >> $HOME/.vimrc
echo "set number" >> $HOME/.vimrc
echo "set is" >> $HOME/.vimrc
echo "set cindent" >> $HOME/.vimrc
echo "set expandtab" >> $HOME/.vimrc
echo "set tabstop=4" >> $HOME/.vimrc
echo "set shiftwidth=4" >> $HOME/.vimrc
echo "set mouse=a" >> $HOME/.vimrc
echo "set splitright" >> $HOME/.vimrc
# Plug
echo >> $HOME/.vimrc
echo "call plug#begin('\''~/.vim/plugged'\'')" >> $HOME/.vimrc
echo >> $HOME/.vimrc
echo "Plug '\''https://github.com/NLKNguyen/papercolor-theme'\''" >> $HOME/.vimrc
echo >> $HOME/.vimrc
echo "call plug#end()" >> $HOME/.vimrc
echo >> $HOME/.vimrc
# Color Theme
echo "set t_Co=256" >> $HOME/.vimrc
echo "set background=dark" >> $HOME/.vimrc
echo "colorscheme PaperColor" >> $HOME/.vimrc
# Keyboard Shortcuts remap
echo >> $HOME/.vimrc
echo "tnoremap <Esc><Esc> <C-\><C-n>" >> $HOME/.vimrc
echo "tnoremap <C-h> <C-\><C-n><C-w>h" >> $HOME/.vimrc
echo "tnoremap <C-j> <C-\><C-n><C-w>j" >> $HOME/.vimrc
echo "tnoremap <C-k> <C-\><C-n><C-w>k" >> $HOME/.vimrc
echo "tnoremap <C-l> <C-\><C-n><C-w>l" >> $HOME/.vimrc
echo "nnoremap <C-h> <C-w>h" >> $HOME/.vimrc
echo "nnoremap <C-j> <C-w>j" >> $HOME/.vimrc
echo "nnoremap <C-k> <C-w>k" >> $HOME/.vimrc
echo "nnoremap <C-l> <C-w>l" >> $HOME/.vimrc

# Vim Pluginstall
vim -c PlugInstall -c qa

# Aliases

